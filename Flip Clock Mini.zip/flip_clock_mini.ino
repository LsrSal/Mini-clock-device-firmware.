#include <ESP8266WiFi.h>
#include <time.h>
#include <EEPROM.h>
#define FS_NO_GLOBALS
#include <FS.h>
#include <LittleFS.h>
#include <TFT_eSPI.h>

// Initialize TFT instance for 240x240 display
TFT_eSPI tft = TFT_eSPI();

// EEPROM configuration structure with version magic header
struct Config {
  uint32_t magicHeader;
  char ssid[32];
  char pass[64];
  char ntpServer[64];
  float gmtOffset;
  int brightness;
  unsigned long updateInterval;
};

const uint32_t CONFIG_MAGIC = 0xAF020160;
Config cfg;

const int TFT_BL_PIN = 5; // Backlight pin on GPIO 5

int lastDisplayedHour = -1;
int lastDisplayedMin = -1;
unsigned long lastNtpSyncTime = 0;

void loadConfig();
void saveConfig();
void parseSerialCommand(String cmd);
void drawBmp(const char *filename, int16_t x, int16_t y);
void drawColon(int16_t x, int16_t y, bool show);
void updateClockDisplay(int h, int m);

void setup() {
  Serial.begin(115200);
  delay(500);

  // 1. Load configuration from EEPROM first
  EEPROM.begin(512);
  loadConfig();

  // 2. Initialize display FIRST (ensure User_Setup.h has backlight config removed)
  tft.init();
  tft.setRotation(0);
  tft.fillScreen(TFT_BLACK);

  // 3. Initialize Backlight PWM on GPIO 5 (Inverted) using loaded brightness
  pinMode(TFT_BL_PIN, OUTPUT);
  analogWriteRange(1023);
  analogWriteFreq(1000);
  int initialBrightness = map(cfg.brightness, 0, 1023, 0, 1023);
  analogWrite(TFT_BL_PIN, 1023 - initialBrightness);

  // Initialize LittleFS and list files for debugging
  if (!LittleFS.begin()) {
    Serial.println(F("ERROR: LittleFS initialization failed!"));
  } else {
    Serial.println(F("LittleFS mounted successfully. Files found:"));
    Dir dir = LittleFS.openDir("/");
    while (dir.next()) {
      Serial.print("  - ");
      Serial.print(dir.fileName());
      Serial.print(" (");
      Serial.print(dir.fileSize());
      Serial.println(" bytes)");
    }
  }

  // Connect to WiFi
  if (strlen(cfg.ssid) > 0) {
    Serial.printf("Connecting to WiFi: %s\n", cfg.ssid);
    WiFi.persistent(false);
    WiFi.mode(WIFI_STA);
    WiFi.begin(cfg.ssid, cfg.pass);
    
    unsigned long startAttempt = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - startAttempt < 15000) {
      delay(500);
      Serial.print(".");
      yield();
    }
    Serial.println();
    
    if (WiFi.status() == WL_CONNECTED) {
      Serial.printf("WiFi Connected! IP Address: %s\n", WiFi.localIP().toString().c_str());
    } else {
      Serial.println(F("WiFi Connection timeout. Continuing offline..."));
    }
  } else {
    Serial.println(F("No WiFi SSID configured. Type '?' for help or use SET_WIFI <ssid> <password>."));
  }

  configTime((int)(cfg.gmtOffset * 3600), 0, cfg.ntpServer, "pool.ntp.org", "time.nist.gov");
  lastNtpSyncTime = millis();
}

void loop() {
  // Handle incoming Serial terminal commands
  if (Serial.available()) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    if (input.length() > 0) {
      parseSerialCommand(input);
    }
  }

  // Periodic NTP re-sync based on configured update interval (convert seconds to milliseconds)
  if (WiFi.status() == WL_CONNECTED && (millis() - lastNtpSyncTime > (cfg.updateInterval * 1000UL))) {
    configTime((int)(cfg.gmtOffset * 3600), 0, cfg.ntpServer, "pool.ntp.org", "time.nist.gov");
    lastNtpSyncTime = millis();
    Serial.println(F("INFO: Triggered periodic NTP time re-sync."));
  }

  // Check NTP time and update display when time is synced
  time_t now = time(nullptr);
  int currentHour, currentMin;
  
  if (now > 1600000000) {
    struct tm *timeinfo = localtime(&now);
    currentHour = timeinfo->tm_hour;
    currentMin = timeinfo->tm_min;
  } else {
    // Fallback demo timer if NTP hasn't synced yet
    unsigned long seconds = millis() / 5000;
    currentHour = seconds % 13;
    currentMin = (seconds * 5) % 60;
  }

  if (currentHour != lastDisplayedHour || currentMin != lastDisplayedMin) {
    updateClockDisplay(currentHour, currentMin);
    lastDisplayedHour = currentHour;
    lastDisplayedMin = currentMin;
  }

  delay(200);
}

// BMP drawing function with slowed down animation pacing (/4)
void drawBmp(const char *filename, int16_t x, int16_t y) {
  char fullpath[32];
  if (filename[0] != '/') {
    snprintf(fullpath, sizeof(fullpath), "/%s", filename);
  } else {
    snprintf(fullpath, sizeof(fullpath), "%s", filename);
  }

  File bmpFS = LittleFS.open(fullpath, "r");
  if (!bmpFS) {
    Serial.printf("CRITICAL: Cannot open file: %s\n", fullpath);
    return;
  }

  uint32_t seekOffset = 0;
  uint16_t w = 0, h = 0;
  uint8_t  buff[4];

  if (bmpFS.read(buff, 2) != 2) { bmpFS.close(); return; }
  if (buff[0] != 'B' || buff[1] != 'M') {
    Serial.printf("CRITICAL: Not a valid BMP file: %s\n", fullpath);
    bmpFS.close();
    return;
  }

  bmpFS.seek(10);
  bmpFS.read((uint8_t *)&seekOffset, 4);

  bmpFS.seek(18);
  bmpFS.read((uint8_t *)&w, 2);
  bmpFS.seek(22);
  bmpFS.read((uint8_t *)&h, 2);

  uint16_t depth = 0;
  bmpFS.seek(28);
  bmpFS.read((uint8_t *)&depth, 2);

  if (depth == 24 && w > 0 && h > 0) {
    uint32_t rowSize = (w * 3 + 3) & (~3);
    uint8_t rowBuffer[rowSize];

    tft.startWrite();
    for (int row = 0; row < h; row++) {
      uint32_t pos = seekOffset + ((h - 1 - row) * rowSize);
      bmpFS.seek(pos);
      bmpFS.read(rowBuffer, rowSize);

      uint8_t *bptr = rowBuffer;
      for (int col = 0; col < w; col++) {
        uint8_t b = *bptr++;
        uint8_t g = *bptr++;
        uint8_t r = *bptr++;

        uint16_t color = tft.color565(r, g, b);
        tft.drawPixel(x + col, y + row, color);
      }
      
      // Animation slowdown pacing (/4)
      if (row % 4 == 0) {
        delayMicroseconds(400);
        yield();
      }
    }
    tft.endWrite();
  }

  bmpFS.close();
}

// Render colon separator
void drawColon(int16_t x, int16_t y, bool show) {
  uint16_t color = show ? TFT_WHITE : TFT_BLACK;
  tft.fillRect(x, y + 60, 15, 15, color);
  tft.fillRect(x, y + 125, 15, 15, color);
}

// Layout for 240x240 display:
// Hour digit: X = 0, Colon: X = 75, Min Tens: X = 90, Min Ones: X = 165
void updateClockDisplay(int h, int m) {
  int hourVal = h % 12;
  if (hourVal == 0) hourVal = 12;
  int minTens = m / 10;
  int minOnes = m % 10;

  char path[32];

  sprintf(path, "/flip_%02d.bmp", hourVal);
  drawBmp(path, 0, 20);

  drawColon(75, 20, true);

  sprintf(path, "/flip_%02d.bmp", minTens);
  drawBmp(path, 90, 20);

  sprintf(path, "/flip_%02d.bmp", minOnes);
  drawBmp(path, 165, 20);
}

void parseSerialCommand(String cmd) {
  if (cmd.startsWith("SET_WIFI ")) {
    int firstSpace = cmd.indexOf(' ');
    int secondSpace = cmd.indexOf(' ', firstSpace + 1);
    if (secondSpace > 0) {
      String s = cmd.substring(firstSpace + 1, secondSpace);
      String p = cmd.substring(secondSpace + 1);
      s.toCharArray(cfg.ssid, sizeof(cfg.ssid));
      p.toCharArray(cfg.pass, sizeof(cfg.pass));
      saveConfig();
      Serial.println(F("OK: WiFi saved. Connecting..."));
      WiFi.begin(cfg.ssid, cfg.pass);
    } else {
      Serial.println(F("ERROR: Use SET_WIFI <ssid> <password>"));
    }
  } 
  else if (cmd.startsWith("SET_NTP ")) {
    String server = cmd.substring(8);
    server.trim();
    server.toCharArray(cfg.ntpServer, sizeof(cfg.ntpServer));
    saveConfig();
    Serial.println(F("OK: NTP server saved."));
    configTime((int)(cfg.gmtOffset * 3600), 0, cfg.ntpServer, "pool.ntp.org");
    lastNtpSyncTime = millis();
  } 
  else if (cmd.startsWith("SET_GMT ")) {
    cfg.gmtOffset = cmd.substring(8).toFloat();
    saveConfig();
    Serial.println(F("OK: GMT offset saved."));
    configTime((int)(cfg.gmtOffset * 3600), 0, cfg.ntpServer, "pool.ntp.org");
    lastNtpSyncTime = millis();
  } 
  else if (cmd.startsWith("SET_UPDATE_INTERVAL ")) {
    unsigned long interval = cmd.substring(20).toInt();
    if (interval >= 60) {
      cfg.updateInterval = interval;
      saveConfig();
      lastNtpSyncTime = millis();
      Serial.printf("OK: Update interval set to %lu seconds.\n", cfg.updateInterval);
    } else {
      Serial.println(F("ERROR: Update interval must be at least 60 seconds."));
    }
  }
  else if (cmd.startsWith("SET_BRIGHTNESS ")) {
    int b = cmd.substring(15).toInt();
    if (b >= 0 && b <= 1023) {
      cfg.brightness = b;
      saveConfig();
      int mappedBrightness = map(cfg.brightness, 0, 1023, 0, 1023);
      analogWrite(TFT_BL_PIN, 1023 - mappedBrightness);
      Serial.printf("OK: Backlight brightness updated to %d and saved to EEPROM.\n", cfg.brightness);
    } else {
      Serial.println(F("ERROR: Value must be between 0 and 1023."));
    }
  } 
  else if (cmd == "INFO") {
    Serial.println(F("--- SYSTEM INFO ---"));
    Serial.printf("SSID: %s\n", cfg.ssid);
    Serial.printf("NTP Server: %s\n", cfg.ntpServer);
    Serial.printf("GMT Offset: %.1f\n", cfg.gmtOffset);
    Serial.printf("Update Interval: %lu seconds\n", cfg.updateInterval);
    Serial.printf("Brightness: %d\n", cfg.brightness);
    Serial.printf("WiFi Status: %s\n", WiFi.status() == WL_CONNECTED ? "CONNECTED" : "DISCONNECTED");
    if (WiFi.status() == WL_CONNECTED) {
      Serial.printf("IP Address: %s\n", WiFi.localIP().toString().c_str());
    }
    Serial.println(F("-------------------"));
  } 
  else if (cmd == "RESTART") {
    Serial.println(F("Restarting ESP8266..."));
    ESP.restart();
  } 
  else if (cmd == "?") {
    Serial.println(F("================================================="));
    Serial.println(F("             ESP8266 FLIP CLOCK HELP             "));
    Serial.println(F("================================================="));
    Serial.println(F("  SET_WIFI <ssid> <pass>      - Configure Wi-Fi credentials"));
    Serial.println(F("  SET_NTP <server>            - Set NTP time server address"));
    Serial.println(F("  SET_GMT <offset>            - Set GMT time offset (e.g., -5)"));
    Serial.println(F("  SET_UPDATE_INTERVAL <secs>  - Set time sync period (min 60s)"));
    Serial.println(F("  SET_BRIGHTNESS <0-1023>     - Set backlight intensity (GPIO 5)"));
    Serial.println(F("  INFO                        - Print current status & config"));
    Serial.println(F("  RESTART                     - Reboot the device"));
    Serial.println(F("  ?                           - Display this help menu"));
    Serial.println(F("================================================="));
  } 
  else {
    Serial.println(F("ERROR: Unknown command. Type '?' for available commands."));
  }
}

void loadConfig() {
  EEPROM.get(0, cfg);
  if (cfg.magicHeader != CONFIG_MAGIC || cfg.brightness < 0 || cfg.brightness > 1023 || cfg.updateInterval < 60) {
    cfg.magicHeader = CONFIG_MAGIC;
    strcpy(cfg.ssid, "");
    strcpy(cfg.pass, "");
    strcpy(cfg.ntpServer, "pool.ntp.org");
    cfg.gmtOffset = 0.0;
    cfg.brightness = 800;
    cfg.updateInterval = 3600;
    saveConfig();
  }
}

void saveConfig() {
  cfg.magicHeader = CONFIG_MAGIC;
  EEPROM.put(0, cfg);
  EEPROM.commit();
}
